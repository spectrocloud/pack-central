# Fluent Bit Helm Chart Changelog

> [!NOTE]
> All notable changes to this project will be documented in this file; the format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

<!--
### Added - For new features.
### Changed - For changes in existing functionality.
### Deprecated - For soon-to-be removed features.
### Removed - For now removed features.
### Fixed - For any bug fixes.
### Security - In case of vulnerabilities.
-->

## [UNRELEASED]

## [v0.56.0] - 2026-02-27

### Added

- VPA recommender may be specified with `.autoscaling.vpa.recommender`

## [v0.55.1] - 2026-02-27

### Changed

- Update _Fluent Bit_ OCI image to [v4.2.3](https://github.com/fluent/fluent-bit/releases/tag/v4.2.3). ([#697](https://github.com/fluent/helm-charts/pull/697)) _@stevehipwell_

## [v0.55.0] - 2026-01-22

### Changed

- Update Fluent Bit OCI image to [4.2.2](https://github.com/fluent/fluent-bit/releases/tag/v4.2.2). ([#684](https://github.com/fluent/helm-charts/pull/684)) _@stevehipwell_

## [v0.54.1] - 2026-01-06

### Changed

- Update Fluent Bit OCI image to [4.1.1](https://github.com/fluent/fluent-bit/releases/tag/v4.1.1). ([#639](https://github.com/fluent/helm-charts/pull/666)) _@Xelus22_

## [v0.54.0] - 2025-10-09

### Changed

- Update Fluent Bit OCI image to [4.1.0](https://github.com/fluent/fluent-bit/releases/tag/v4.1.0). ([#639](https://github.com/fluent/helm-charts/pull/639)) _@timonegk_

<!--
RELEASE LINKS
-->

[UNRELEASED]: https://github.com/fluent/helm-charts/tree/main/charts/fluent-bit
[v0.56.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.56.0
[v0.55.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.55.1
[v0.55.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.55.0
[v0.54.1]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.54.1
[v0.54.0]: https://github.com/fluent/helm-charts/releases/tag/fluent-bit-0.54.0
