#!/bin/sh
# apply_nvdec_patch.sh — overlay the NVDEC decode backend into the gated rt-embed rootfs at
# deploy time (build-on-deploy). Idempotent; safe to re-run. Runs inside the rtvi-embed
# container after the rootfs is crane-fetched, BEFORE start_rtvi_embed.sh.
#
# Selected by RTVI_DECODE_BACKEND=nvdec. With any other value it is a no-op (stock pyds path).
#
# It does two things, both grounded in the extracted rootfs source
# (rtvi/vlm_pipeline/vlm_pipeline.py + video_file_frame_getter.py @ vss-rt-embed:3.1.0):
#   1. Copy nvdec_frame_getter.py next to the stock getter.
#   2. Patch vlm_pipeline._initialize's local import (line ~190):
#        from .video_file_frame_getter import DefaultFrameSelector, VideoFileFrameGetter
#      so that under nvdec it binds VideoFileFrameGetter -> NvDecFrameGetter WITHOUT importing
#      video_file_frame_getter (which imports pyds/gi at module top). DefaultFrameSelector is
#      still imported from the stock module — it's pure-python (no pyds) so it loads fine; the
#      pyds import only happens at `import gi`/`import pyds` which we now avoid by not importing
#      VideoFileFrameGetter. (DefaultFrameSelector sits above those module-level imports? NO —
#      they're at top of file, so importing DefaultFrameSelector still triggers pyds. Therefore
#      we ALSO provide a pyds-free DefaultFrameSelector in nvdec_frame_getter and rebind both.)
set -e
[ "${RTVI_DECODE_BACKEND:-}" = "nvdec" ] || { echo "[nvdec-patch] backend!=nvdec, skip"; exit 0; }

RT="${1:-/runtime}"
VP_DIR="$RT/opt/nvidia/rtvi/rtvi/vlm_pipeline"
SRC_GETTER="${2:-/nvdec/nvdec_frame_getter.py}"   # mounted from ConfigMap
PYBIN="${PYBIN:-python3}"

[ -d "$VP_DIR" ] || { echo "[nvdec-patch] $VP_DIR not found"; exit 1; }

# VERIFIED (rootfs inspection 2026-06-15): vss-rt-embed:3.1.0 does NOT bundle PyNvVideoCodec
# or libnvcuvid, and the rtvi code never imports PyNvVideoCodec. So unlike the earlier
# assumption, the backend is NOT already present — we must install it at deploy. libnvcuvid
# itself is injected by the GPU driver at runtime (requires NVIDIA_DRIVER_CAPABILITIES to
# include "video" — set it on the rtvi-embed Deployment).
if ! "$PYBIN" -c 'import PyNvVideoCodec' 2>/dev/null; then
  echo "[nvdec-patch] PyNvVideoCodec absent -> pip install (NVIDIA wheel)"
  "$PYBIN" -m pip install --no-cache-dir PyNvVideoCodec || {
    echo "[nvdec-patch] FATAL: PyNvVideoCodec install failed (need network to PyPI/NGC + aarch64 wheel)"; exit 1; }
fi
"$PYBIN" -c 'import ctypes; ctypes.CDLL("libnvcuvid.so.1")' 2>/dev/null \
  || echo "[nvdec-patch] WARN: libnvcuvid not loadable — ensure NVIDIA_DRIVER_CAPABILITIES includes 'video'"
cp -f "$SRC_GETTER" "$VP_DIR/nvdec_frame_getter.py"
echo "[nvdec-patch] copied nvdec_frame_getter.py"

PY="$VP_DIR/vlm_pipeline.py"
if ! grep -q "RTVI_DECODE_BACKEND" "$PY"; then
  # Replace the stock local import line with a backend switch. NvDecFrameGetter is a drop-in
  # for VideoFileFrameGetter; for nvdec we also use the stock DefaultFrameSelector ONLY if it
  # imports without pyds — it does not, so we expose a NvDecDefaultFrameSelector alias.
  python3 - "$PY" <<'PYEOF'
import io, re, sys
p = sys.argv[1]
s = io.open(p, encoding="utf-8").read()
needle = "from .video_file_frame_getter import DefaultFrameSelector, VideoFileFrameGetter"
repl = (
    "import os as _os\n"
    "        if _os.environ.get('RTVI_DECODE_BACKEND', '').lower() == 'nvdec':\n"
    "            from .nvdec_frame_getter import (\n"
    "                NvDecDefaultFrameSelector as DefaultFrameSelector,\n"
    "                NvDecFrameGetter as VideoFileFrameGetter,\n"
    "            )\n"
    "        else:\n"
    "            from .video_file_frame_getter import DefaultFrameSelector, VideoFileFrameGetter"
)
# every occurrence of the local import inside methods (there are 3: _initialize, live paths)
s2 = s.replace(needle, repl)
# the live-stream paths import only DefaultFrameSelector; handle that too
s2 = s2.replace(
    "from .video_file_frame_getter import DefaultFrameSelector\n",
    "import os as _os\n"
    "        if _os.environ.get('RTVI_DECODE_BACKEND', '').lower() == 'nvdec':\n"
    "            from .nvdec_frame_getter import NvDecDefaultFrameSelector as DefaultFrameSelector\n"
    "        else:\n"
    "            from .video_file_frame_getter import DefaultFrameSelector\n",
)
io.open(p, "w", encoding="utf-8").write(s2)
print("[nvdec-patch] patched", p)
PYEOF
else
  echo "[nvdec-patch] vlm_pipeline.py already patched"
fi
echo "[nvdec-patch] done"
