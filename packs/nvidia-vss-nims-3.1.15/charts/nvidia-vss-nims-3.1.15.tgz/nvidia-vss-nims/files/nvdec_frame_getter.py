# nvdec_frame_getter.py — self-contained dGPU decode path for rtvi-embed.
#
# WHY: rtvi-embed's stock decoder (vlm_pipeline/video_file_frame_getter.py) decodes via a
# GStreamer/DeepStream pipeline (nvv4l2decoder -> pyds.get_nvds_buf_surface_gpu) and imports
# `pyds`/`gi` at module top. On a DGX Spark in *dGPU mode* (default DGX OS) that path needs the
# L4T/Tegra kernel-driver stack (libnvrm_mem/libnvos -> /dev/nvmap) which is ABSENT. This getter
# decodes via PyNvVideoCodec's SimpleDecoder (NVDEC through libnvcuvid, present on the dGPU node),
# producing the SAME preprocessed tensors the embed model consumes — no DeepStream, no Tegra,
# no `pyds`/`gi` import. Overlaid into the gated rootfs at deploy (build-on-deploy) and selected
# by RTVI_DECODE_BACKEND=nvdec (vlm_pipeline._initialize imports this instead of the stock getter).
#
# INTERFACE — grounded in the EXTRACTED rootfs source (vlm_pipeline/video_file_frame_getter.py
# @ vss-rt-embed:3.1.0). Constructor mirrors VideoFileFrameGetter.__init__ exactly (frame_selector
# first, then the kwargs vlm_pipeline._initialize passes at the instantiation site); the input
# file comes from `chunk.file` per call (the getter is reused across chunks), NOT the constructor.
#   get_frames(chunk) -> (frames, frame_times, audio_frames, error)
#     frames:       list[torch.Tensor]  CHW float (preprocessed) if do_preprocess else HWC uint8 RGB
#     frame_times:  list[float]         PTS seconds per frame
#     audio_frames: list                empty (audio not needed for embedding)
#     error:        Optional[str]
#
# Preprocessing replicates the stock chain (video_file_frame_getter.py lines ~607-678):
#   decode -> RGB HWC uint8 -> resize(shortest_edge or frame_w/h) -> center_crop(crop_h/w)
#   -> Rescale(rescale_factor) (== float()*factor) -> normalize(image_mean,image_std) -> ToCHW.
#
# STILL TODO(validate on GB10, needs a free GPU slot):
#   - NV12->RGB: confirm the in-image PyNvVideoCodec default surface format; if frames come back
#     NV12, _to_rgb_tensor must do the NV12->RGB conversion (cv-cuda / fused kernel).
#   - frame-selection parity vs DefaultFrameSelector PTS (off-by-one at chunk boundaries).
#   - embedding-equivalence: cosine(stock, nvdec) ~= 1.0 for a known clip.
#   - RTSP/live is NOT covered (SimpleDecoder is file-oriented) -> live needs the stock L4T path.

import logging
from typing import Optional

import torch
import torch.nn.functional as F

try:
    from torchvision.transforms import v2 as _tvv2  # same lib the stock getter uses
except Exception:  # pragma: no cover
    _tvv2 = None

logger = logging.getLogger("nvdec_frame_getter")


class NvDecDefaultFrameSelector:
    """pyds-free stand-in for video_file_frame_getter.DefaultFrameSelector.

    The stock DefaultFrameSelector lives in a module that imports pyds/gi at top level, so we
    cannot import it under the nvdec backend. We only need the frame COUNT (N equally-spaced
    frames per chunk); NvDecFrameGetter does the PTS spacing itself. Mirrors the stock
    constructor: DefaultFrameSelector(num_frames_per_second_or_fixed_frames=8, ...).
    """

    def __init__(self, num_frames_per_second_or_fixed_frames=8, use_fps_for_chunking=False):
        self._num_frames = int(num_frames_per_second_or_fixed_frames or 8)
        self.num_frames = self._num_frames
        self._use_fps_for_chunking = use_fps_for_chunking

    def set_chunk(self, chunk):  # stock API compatibility (no-op; NvDec computes spacing)
        self._chunk = chunk


class NvDecFrameGetter:
    """NVDEC (PyNvVideoCodec) drop-in for VideoFileFrameGetter, file-input case, dGPU-only."""

    def __init__(
        self,
        frame_selector,
        frame_width=0,
        frame_height=0,
        gpu_id=0,
        do_preprocess=False,
        image_mean=[],
        rescale_factor=0,
        image_std=0,
        crop_height=0,
        crop_width=0,
        shortest_edge: Optional[int] = None,
        enable_jpeg_output=False,
        image_aspect_ratio="",
        data_type_int8=False,
        audio_support=False,
        cv_pipeline_configs={},
        **_ignored,
    ):
        self._frame_selector = frame_selector
        self._frame_width = frame_width
        self._frame_height = frame_height
        self._gpu_id = gpu_id
        self._do_preprocess = do_preprocess
        self._image_mean = image_mean
        self._rescale_factor = rescale_factor
        self._image_std = image_std
        self._crop_height = crop_height
        self._crop_width = crop_width
        self._shortest_edge = shortest_edge
        self._enable_jpeg_output = enable_jpeg_output
        self._image_aspect_ratio = image_aspect_ratio
        self._data_type_int8 = data_type_int8
        self._audio_support = audio_support
        self._dec = None
        self._dec_file = None

    # -- decoder is per-file; reuse across chunks of the same file --------------------------
    def _decoder(self, file_path):
        if self._dec is None or self._dec_file != file_path:
            import PyNvVideoCodec as nvc  # lazy: only when this backend is actually selected
            self._dec = nvc.SimpleDecoder(file_path, gpu_id=self._gpu_id)
            self._dec_file = file_path
        return self._dec

    def get_frames(self, chunk):
        try:
            dec = self._decoder(chunk.file)

            # N equally-spaced PTS in [start,end] — mirror DefaultFrameSelector
            # (pts_diff=(end-start)/N; pts_i = start + i*pts_diff). PTS on ChunkInfo are ns.
            start_s = float(getattr(chunk, "start_pts", 0) or 0) / 1e9
            end_s = float(getattr(chunk, "end_pts", 0) or 0) / 1e9
            n = self._num_frames()
            if end_s <= start_s:  # whole-file chunk: span the stream
                meta = dec.get_stream_metadata()
                end_s = float(getattr(meta, "duration", 0) or getattr(meta, "num_frames", 0) or 0)
            pts_diff = (end_s - start_s) / n if n else 0.0
            want_s = [start_s + i * pts_diff for i in range(n)]

            idxs = [dec.get_index_from_time_in_seconds(p) for p in want_s]
            batch = dec.get_batch_frames_by_index(idxs)

            frames, frame_times = [], []
            for p, fr in zip(want_s, batch):
                t = self._to_rgb_tensor(fr)               # HWC uint8 RGB (GPU)
                t = self._preprocess(t)
                frames.append(t)
                frame_times.append(p)
            return frames, frame_times, [], None
        except Exception as exc:
            logger.exception("NVDEC get_frames failed")
            return [], [], [], f"nvdec decode error: {exc}"

    def _num_frames(self):
        for attr in ("_num_frames", "num_frames", "_nfrms", "num_frames_per_second_or_fixed_frames"):
            v = getattr(self._frame_selector, attr, None)
            if v:
                return int(v)
        return 8

    # -- preprocessing parity with the stock getter ----------------------------------------
    def _preprocess(self, t_hwc_uint8):
        # resize: shortest_edge wins (HF-style) else explicit frame_width/height
        if self._shortest_edge:
            h, w = t_hwc_uint8.shape[0], t_hwc_uint8.shape[1]
            scale = self._shortest_edge / min(h, w)
            t_hwc_uint8 = self._resize(t_hwc_uint8, int(round(w * scale)), int(round(h * scale)))
        elif self._frame_width and self._frame_height:
            t_hwc_uint8 = self._resize(t_hwc_uint8, self._frame_width, self._frame_height)

        if not self._do_preprocess:
            return t_hwc_uint8  # HWC uint8 RGB (jpeg/raw path)

        chw = t_hwc_uint8.permute(2, 0, 1).contiguous()          # ToCHW
        if self._crop_height and self._crop_width and _tvv2 is not None:
            chw = _tvv2.functional.center_crop(chw, [self._crop_height, self._crop_width])
        factor = self._rescale_factor or (1.0 / 255.0)
        chw = chw.float().mul(factor)                            # Rescale
        if _tvv2 is not None and self._image_mean is not None and self._image_std:
            mean = self._image_mean if self._image_mean else [0.0, 0.0, 0.0]
            std = self._image_std if isinstance(self._image_std, (list, tuple)) else [self._image_std] * 3
            chw = _tvv2.functional.normalize(chw, mean=list(mean), std=list(std))
        return chw

    @staticmethod
    def _to_rgb_tensor(frame):
        # VALIDATED on GB10 (PyNvVideoCodec 2.1.0): SimpleDecoder frames come back as a 2-D
        # **NV12** surface (DLPack tensor of shape (H*3/2, W) uint8) — NOT HWC RGB. (Confirmed:
        # a raw frame reached _resize as input.dim()==2.) Convert NV12 -> HWC RGB uint8 here.
        try:
            t = torch.utils.dlpack.from_dlpack(frame)
        except Exception:
            import cupy as cp
            t = torch.as_tensor(cp.asarray(frame), device="cuda")
        if t.dim() == 3 and t.shape[-1] in (3, 4):
            return t[..., :3].to(torch.uint8)              # already HWC RGB(A)
        if t.dim() == 2:                                    # NV12: Y plane (H,W) + interleaved UV
            Hx, W = int(t.shape[0]), int(t.shape[1])
            H = (Hx * 2) // 3
            y = t[:H, :].float()
            uv = t[H:H + H // 2, :].reshape(H // 2, W // 2, 2).float()
            u = uv[:, :, 0].repeat_interleave(2, 0).repeat_interleave(2, 1)[:H, :W]
            v = uv[:, :, 1].repeat_interleave(2, 0).repeat_interleave(2, 1)[:H, :W]
            c = y - 16.0; d = u - 128.0; e = v - 128.0     # BT.601 limited-range YUV->RGB
            r = (1.164 * c + 1.596 * e).clamp(0, 255)
            g = (1.164 * c - 0.392 * d - 0.813 * e).clamp(0, 255)
            b = (1.164 * c + 2.017 * d).clamp(0, 255)
            return torch.stack([r, g, b], dim=2).to(torch.uint8)   # HWC RGB
        raise RuntimeError(f"unexpected NVDEC frame shape {tuple(t.shape)}")

    @staticmethod
    def _resize(t_hwc, w, h):
        x = t_hwc.permute(2, 0, 1).unsqueeze(0).float()
        x = F.interpolate(x, size=(h, w), mode="bilinear", align_corners=False)
        return x.squeeze(0).permute(1, 2, 0).round().clamp(0, 255).to(torch.uint8)
