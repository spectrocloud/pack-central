{{/*
Expand the name of the chart.
*/}}
{{- define "gridlight.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "gridlight.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels applied to all resources.
*/}}
{{- define "gridlight.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "gridlight.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/*
Selector labels (stable — used in matchLabels; never add fields that change).
*/}}
{{- define "gridlight.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gridlight.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Resolve image reference: registry/repository:tag.
Handles the case where repository is a template string in values.yaml.
*/}}
{{- define "gridlight.image" -}}
{{- $reg := .Values.global.imageRegistry -}}
{{- $tag := .Values.global.imageTag -}}
{{- printf "%s/%s:%s" $reg .repo $tag -}}
{{- end }}

{{/*
Resolve the effective list of imagePullSecrets.
Uses the chart-managed regcred when registryCredentials is set,
otherwise falls back to global.imagePullSecrets.
*/}}
{{- define "gridlight.imagePullSecrets" -}}
{{- if .Values.auth.registryCredentials }}
- name: {{ include "gridlight.fullname" . }}-regcred
{{- else }}
{{- range .Values.global.imagePullSecrets }}
- name: {{ . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Gateway service DNS name (used by agents to register).
*/}}
{{- define "gridlight.gatewayURL" -}}
{{- printf "http://%s-gateway:%d" (include "gridlight.fullname" .) (.Values.gateway.port | int) -}}
{{- end }}

{{/*
PostgreSQL DSN assembled from in-cluster values.
*/}}
{{- define "gridlight.postgresURL" -}}
{{- printf "postgresql://gridlight:$(POSTGRES_PASSWORD)@%s-postgres:%d/gridlight" (include "gridlight.fullname" .) (.Values.postgres.port | int) -}}
{{- end }}

{{/*
Neo4j Bolt URL.
*/}}
{{- define "gridlight.neo4jURL" -}}
{{- printf "bolt://%s-neo4j:%d" (include "gridlight.fullname" .) (.Values.neo4j.boltPort | int) -}}
{{- end }}

{{/*
Resolved LLM model file path inside the container.
Uses llmAgent.modelPath if set; otherwise derives from models.llm catalog.
*/}}
{{- define "gridlight.llmModelPath" -}}
{{- if .Values.llmAgent.modelPath -}}
{{- .Values.llmAgent.modelPath -}}
{{- else -}}
{{- $cat := index .Values.models.llm.catalog .Values.models.llm.category -}}
{{- $m := index $cat .Values.models.llm.preset -}}
{{- if $m.subdir -}}
{{- printf "%s/models/llm/%s/%s" .Values.dataDir $m.subdir $m.filename -}}
{{- else -}}
{{- printf "%s/models/llm/%s" .Values.dataDir $m.filename -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Storage helper family (FLEET-001).
Each template takes a dict: { "agent": <agent values block>, "ctx": $, "component": "<label>" }
  agent.storage.mode             — shared | ownPvc | emptyDir   (default: shared, backward compatible)
  agent.storage.size             — ownPvc PVC request / emptyDir sizeLimit
  agent.storage.accessMode       — ownPvc only: ReadWriteOnce | ReadWriteOncePod (default: ReadWriteOnce)
  agent.storage.storageClassName — ownPvc only; falls back to .Values.pvc.storageClassName
These emit snippets only — the parent template owns the resource kind (matches every
other helper here). StatefulSet/volumeClaimTemplates for replicas>1 is FLEET-003.
*/}}
{{- define "gridlight.agentStorage.mode" -}}
{{- default "shared" (default (dict) .agent.storage).mode -}}
{{- end }}

{{- define "gridlight.agentStorage.claimName" -}}
{{- printf "%s-%s-data" (include "gridlight.fullname" .ctx) .component -}}
{{- end }}

{{/* volumes: entry named "data". Splice under `volumes:` via `| nindent 8`. */}}
{{- define "gridlight.agentStorage.volumes" -}}
{{- $mode := include "gridlight.agentStorage.mode" . -}}
{{- $s := default (dict) .agent.storage -}}
- name: data
{{- if eq $mode "shared" }}
  {{- if .ctx.Values.pvc.enabled }}
  persistentVolumeClaim:
    claimName: {{ include "gridlight.fullname" .ctx }}-data
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- else if eq $mode "ownPvc" }}
  persistentVolumeClaim:
    claimName: {{ include "gridlight.agentStorage.claimName" . }}
{{- else if eq $mode "emptyDir" }}
  {{- if $s.size }}
  emptyDir:
    sizeLimit: {{ $s.size }}
  {{- else }}
  emptyDir: {}
  {{- end }}
{{- else }}
  {{- fail (printf "invalid %s.storage.mode %q — must be shared|ownPvc|emptyDir" .component $mode) }}
{{- end }}
{{- end }}

{{/* volumeMounts: entry named "data". Splice under `volumeMounts:` via `| nindent 12`. */}}
{{- define "gridlight.agentStorage.mounts" -}}
- name: data
  mountPath: {{ .ctx.Values.dataDir }}
{{- end }}

{{/* Sibling PVC resource — emitted only for ownPvc mode. Place at file top level. */}}
{{- define "gridlight.agentStorage.pvc" -}}
{{- $mode := include "gridlight.agentStorage.mode" . -}}
{{- if eq $mode "ownPvc" -}}
{{- $s := default (dict) .agent.storage -}}
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: {{ include "gridlight.agentStorage.claimName" . }}
  labels:
    {{- include "gridlight.labels" .ctx | nindent 4 }}
    app.kubernetes.io/component: {{ .component }}
  annotations:
    # Retain the model PVC across helm uninstall/upgrade so large downloads survive.
    helm.sh/resource-policy: keep
spec:
  accessModes:
    - {{ default "ReadWriteOnce" $s.accessMode }}
  resources:
    requests:
      storage: {{ default "20Gi" $s.size }}
  {{- $scn := default .ctx.Values.pvc.storageClassName $s.storageClassName }}
  {{- if $scn }}
  storageClassName: {{ $scn }}
  {{- end }}
{{- end -}}
{{- end }}

{{/*
Resolve an agent type's instances (FLEET-002). Returns a YAML list — consume with
`| fromYamlArray`. args: dict "list" <.Values.fooAgents> "legacy" <.Values.fooAgent>
If the list is non-empty it wins (new fleet style). Otherwise the legacy singular block is
wrapped as ONE instance named "agent", preserving v1.1.2 resource names + labels exactly
({release}-{type}-agent, component {type}-agent). Setting the list ignores the deprecated
singular key (legacy keys always carry chart defaults, so "list wins" is the only coherent rule).
*/}}
{{- define "gridlight.agentInstances" -}}
{{- $list := .list | default (list) -}}
{{- if gt (len $list) 0 -}}
{{- toYaml $list -}}
{{- else if .legacy -}}
{{- toYaml (list (merge (dict "name" "agent") .legacy)) -}}
{{- else -}}
{{- toYaml (list) -}}
{{- end -}}
{{- end }}

{{/*
Per-instance LLM/embed model file path (FLEET-006). args: dict "inst" <instance> "ctx" $
Precedence: instance.modelPath → instance.model.{category,preset} → global models.llm.{category,preset}.
Mirrors the legacy gridlight.llmModelPath resolution so the default instance is byte-identical.
*/}}
{{- define "gridlight.instanceModelPath" -}}
{{- $inst := .inst -}}
{{- $ctx := .ctx -}}
{{- if $inst.modelPath -}}
{{- $inst.modelPath -}}
{{- else -}}
{{- $root := include "gridlight.modelRoot" $ctx -}}
{{- $m := $inst.model | default dict -}}
{{- $category := $m.category | default $ctx.Values.models.llm.category -}}
{{- $preset := $m.preset | default $ctx.Values.models.llm.preset -}}
{{- $cat := index $ctx.Values.models.llm.catalog $category -}}
{{- $entry := index $cat $preset -}}
{{- if $entry.subdir -}}
{{- printf "%s/models/llm/%s/%s" $root $entry.subdir $entry.filename -}}
{{- else -}}
{{- printf "%s/models/llm/%s" $root $entry.filename -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Model storage root (FLEET-001b). The shared cache path when modelCache.enabled, else dataDir.
LLM/embed models resolve under this root so the model-warmer and the agents agree on location.
Arg: the root context ($).
*/}}
{{- define "gridlight.modelRoot" -}}
{{- if and .Values.modelCache .Values.modelCache.enabled -}}
{{- .Values.modelCache.path -}}
{{- else -}}
{{- .Values.dataDir -}}
{{- end -}}
{{- end }}

{{/*
Resolve the catalog entry for an instance's LLM model (used by the download initContainer).
args: dict "inst" <instance> "ctx" $   Returns the catalog entry as YAML (use | fromYaml).
*/}}
{{- define "gridlight.instanceModelEntry" -}}
{{- $inst := .inst -}}
{{- $ctx := .ctx -}}
{{- $m := $inst.model | default dict -}}
{{- $category := $m.category | default $ctx.Values.models.llm.category -}}
{{- $preset := $m.preset | default $ctx.Values.models.llm.preset -}}
{{- $cat := index $ctx.Values.models.llm.catalog $category -}}
{{- toYaml (index $cat $preset) -}}
{{- end }}

{{/*
Per-instance friendly preset name (ROUTE FU-2). args: dict "inst" <instance> "ctx" $
Returns the canonical preset string (e.g. "qwen-7b") the operator selected, which the
agent reports as the gateway's first-class `model` routing identity. Mirrors the preset
resolution in instanceModelPath/instanceModelEntry so the routing name matches the loaded
model. When the instance pins an explicit modelPath (no catalog preset), this falls back to
the global default preset.
*/}}
{{- define "gridlight.instanceModelPreset" -}}
{{- $inst := .inst -}}
{{- $ctx := .ctx -}}
{{- $m := $inst.model | default dict -}}
{{- $m.preset | default $ctx.Values.models.llm.preset -}}
{{- end }}
