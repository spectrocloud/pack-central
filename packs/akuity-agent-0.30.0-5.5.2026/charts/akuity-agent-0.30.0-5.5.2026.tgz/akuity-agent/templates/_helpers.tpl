{{/*
Expand the name of the chart.
*/}}
{{- define "akuity-agent.name" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "akuity-agent.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
app.kubernetes.io/name: {{ include "akuity-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Extra flags for the cluster create command.
*/}}
{{- define "akuity-agent.createFlags" -}}
{{- if .Values.version }} --version {{ .Values.version | quote }}{{- end }}
{{- if .Values.agentSize }} --agent-size {{ .Values.agentSize | quote }}{{- end }}
{{- if .Values.argoprojCustomImageRegistry }} --argoproj-custom-image-registry {{ .Values.argoprojCustomImageRegistry | quote }}{{- end }}
{{- if .Values.project }} --project {{ .Values.project | quote }}{{- end }}
{{- range .Values.labels }} --label {{ . | quote }}{{- end }}
{{- range .Values.annotations }} --annotation {{ . | quote }}{{- end }}
{{- if .Values.disableAutoUpdate }} --disable-auto-update{{- end }}
{{- if .Values.disableAutoUpgrade }} --disable-auto-upgrade{{- end }}
{{- if .Values.stateReplication }} --state-replication{{- end }}
{{- if .Values.redisTunneling }} --redis-tunneling{{- end }}
{{- if .Values.namespaceScoped }} --namespace-scoped{{- end }}
{{- range .Values.extraArgs }} {{ . }}{{- end }}
{{- end }}
