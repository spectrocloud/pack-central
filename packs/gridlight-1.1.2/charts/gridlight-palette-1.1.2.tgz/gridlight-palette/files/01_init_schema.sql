-- GridLight PostgreSQL schema aligned with runtime data models

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE SCHEMA IF NOT EXISTS gridlight;
SET search_path TO gridlight, public;

-- Core tenants table (matches DatabasePool::Tenant)
CREATE TABLE IF NOT EXISTS tenants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    settings JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Users table (minimal fields used by code)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    username TEXT NOT NULL,
    email TEXT,
    access_level TEXT NOT NULL DEFAULT 'user',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Documents table (matches DatabasePool::Document)
CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    source_url TEXT,
    document_type TEXT NOT NULL DEFAULT 'text_chunk',
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Document versions table (lightweight, referenced by chunks)
CREATE TABLE IF NOT EXISTS document_versions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Chunks table (matches DatabasePool::Chunk)
CREATE TABLE IF NOT EXISTS chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    document_version_id UUID NOT NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL DEFAULT 0,
    content TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    vector_id TEXT,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- MEM-IMP-006: SimHash column for near-duplicate detection
ALTER TABLE chunks ADD COLUMN IF NOT EXISTS simhash BIGINT;
CREATE INDEX IF NOT EXISTS idx_chunks_simhash ON chunks(simhash) WHERE simhash IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS idx_chunks_document_version_index
    ON chunks(document_id, document_version_id, chunk_index);

-- Training sessions table (matches DatabasePool::TrainingSession)
CREATE TABLE IF NOT EXISTS training_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES tenants(id) ON DELETE SET NULL,
    session_type TEXT NOT NULL,
    input_data JSONB NOT NULL,
    output_data JSONB,
    metadata JSONB NOT NULL DEFAULT '{}',
    quality_score DOUBLE PRECISION,
    user_feedback TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_by UUID REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_training_sessions_tenant
    ON training_sessions(tenant_id);

-- Trigger to keep updated_at fresh
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS tenants_touch_updated_at ON tenants;
CREATE TRIGGER tenants_touch_updated_at
    BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

DROP TRIGGER IF EXISTS documents_touch_updated_at ON documents;
CREATE TRIGGER documents_touch_updated_at
    BEFORE UPDATE ON documents
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

DROP TRIGGER IF EXISTS chunks_touch_updated_at ON chunks;
CREATE TRIGGER chunks_touch_updated_at
    BEFORE UPDATE ON chunks
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Seed default tenant/user for local development
INSERT INTO tenants (id, name)
VALUES ('00000000-0000-0000-0000-000000000001', 'Default Tenant')
ON CONFLICT (id) DO NOTHING;

INSERT INTO users (id, tenant_id, username, access_level)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    '00000000-0000-0000-0000-000000000001',
    'admin',
    'admin'
) ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- STRUCTURED DATA TABLES (CSV, Excel, JSON, XML)
-- Purpose: Store structured data in PostgreSQL for SQL-based queries
-- ============================================================================

-- Add data_type column to chunks table for routing
ALTER TABLE chunks ADD COLUMN IF NOT EXISTS data_type TEXT DEFAULT 'unstructured';
CREATE INDEX IF NOT EXISTS idx_chunks_data_type ON chunks(data_type);

-- Table to track all structured datasets
CREATE TABLE IF NOT EXISTS structured_datasets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name TEXT NOT NULL UNIQUE,
    original_filename TEXT NOT NULL,
    file_format TEXT NOT NULL,
    domain TEXT NOT NULL,
    category TEXT,
    access_tier TEXT NOT NULL DEFAULT 'internal',
    pii BOOLEAN DEFAULT FALSE,
    row_count INTEGER DEFAULT 0,
    column_count INTEGER DEFAULT 0,
    schema_info JSONB NOT NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid REFERENCES tenants(id) ON DELETE CASCADE,
    sheet_name TEXT
);

-- Migration for existing installations
ALTER TABLE structured_datasets ADD COLUMN IF NOT EXISTS sheet_name TEXT;

CREATE INDEX IF NOT EXISTS idx_structured_datasets_domain ON structured_datasets(domain);
CREATE INDEX IF NOT EXISTS idx_structured_datasets_category ON structured_datasets(category);
CREATE INDEX IF NOT EXISTS idx_structured_datasets_access_tier ON structured_datasets(access_tier);
CREATE INDEX IF NOT EXISTS idx_structured_datasets_tenant ON structured_datasets(tenant_id);
CREATE INDEX IF NOT EXISTS idx_structured_datasets_created ON structured_datasets(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_structured_datasets_sheet ON structured_datasets(original_filename, sheet_name);

-- Function to dynamically create tables for structured data
CREATE OR REPLACE FUNCTION create_structured_table(
    p_table_name TEXT,
    p_columns JSONB
) RETURNS VOID AS $$
DECLARE
    v_sql TEXT;
    v_column JSONB;
    v_col_name TEXT;
    v_col_type TEXT;
    v_columns_def TEXT := '';
BEGIN
    -- Build column definitions
    FOR v_column IN SELECT * FROM jsonb_array_elements(p_columns)
    LOOP
        v_col_name := v_column->>'name';
        v_col_type := v_column->>'data_type';

        -- Sanitize column name
        v_col_name := regexp_replace(v_col_name, '[^a-zA-Z0-9_]', '_', 'g');
        v_col_name := lower(v_col_name);

        -- Map to PostgreSQL types
        v_col_type := CASE
            WHEN v_col_type IN ('integer', 'int') THEN 'INTEGER'
            WHEN v_col_type IN ('numeric', 'decimal', 'float', 'double') THEN 'NUMERIC'
            WHEN v_col_type IN ('boolean', 'bool') THEN 'BOOLEAN'
            WHEN v_col_type = 'date' THEN 'DATE'
            WHEN v_col_type = 'timestamp' THEN 'TIMESTAMP'
            ELSE 'TEXT'
        END;

        IF v_columns_def != '' THEN
            v_columns_def := v_columns_def || ', ';
        END IF;

        v_columns_def := v_columns_def || quote_ident(v_col_name) || ' ' || v_col_type;
    END LOOP;

    -- Create table with standard metadata columns
    v_sql := format('
        CREATE TABLE IF NOT EXISTS %I (
            _row_id SERIAL PRIMARY KEY,
            %s,
            _metadata JSONB,
            _domain TEXT,
            _category TEXT,
            _access_tier TEXT DEFAULT ''internal'',
            _ingested_at TIMESTAMPTZ DEFAULT NOW(),
            _tenant_id UUID DEFAULT ''00000000-0000-0000-0000-000000000001''::uuid
        )', p_table_name, v_columns_def);

    EXECUTE v_sql;

    -- Create indexes
    EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%I_domain ON %I(_domain)', p_table_name, p_table_name);
    EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%I_category ON %I(_category)', p_table_name, p_table_name);
    EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%I_access ON %I(_access_tier)', p_table_name, p_table_name);
    EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%I_tenant ON %I(_tenant_id)', p_table_name, p_table_name);
END;
$$ LANGUAGE plpgsql;

COMMENT ON TABLE structured_datasets IS 'Registry of all structured datasets (CSV, Excel, JSON, XML) with metadata';
COMMENT ON FUNCTION create_structured_table IS 'Dynamically create a table for structured data with appropriate schema';

-- ============================================================================
-- DOCUMENT TABLE STORAGE (Word/PDF table extraction)
-- ============================================================================

CREATE TABLE IF NOT EXISTS document_tables (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_name TEXT NOT NULL,
    document_name_key TEXT NOT NULL,
    table_marker TEXT NOT NULL,
    table_identifier TEXT NOT NULL UNIQUE,
    table_index INT,
    title TEXT,
    headers JSONB,
    row_count INT NOT NULL DEFAULT 0,
    domain TEXT,
    access_tier TEXT,
    categories TEXT[] DEFAULT ARRAY[]::TEXT[],
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS document_tables_doc_marker_idx
    ON document_tables(document_name_key, table_marker);

CREATE TABLE IF NOT EXISTS document_table_rows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_id UUID NOT NULL REFERENCES document_tables(id) ON DELETE CASCADE,
    row_index INT NOT NULL,
    row_data JSONB NOT NULL,
    numeric_values JSONB,
    raw_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS document_table_rows_table_idx
    ON document_table_rows(table_id, row_index);

-- ============================================================================
-- ASYNC UPLOAD DOCUMENTS (background job tracking)
-- ============================================================================

CREATE TABLE IF NOT EXISTS structured_documents (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    domain TEXT NOT NULL,
    access_tier TEXT NOT NULL DEFAULT 'internal',
    pii BOOLEAN NOT NULL DEFAULT false,
    row_count INTEGER NOT NULL DEFAULT 0,
    source_type TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_structured_documents_domain ON structured_documents(domain);
CREATE INDEX IF NOT EXISTS idx_structured_documents_created ON structured_documents(created_at DESC);

COMMENT ON TABLE structured_documents IS 'Tracks documents uploaded via async upload system';

-- ============================================================================
-- RAG-029: Retrieval Metrics Tracking
-- ============================================================================

CREATE TABLE IF NOT EXISTS retrieval_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    query_hash TEXT NOT NULL,
    question TEXT NOT NULL,
    domain TEXT,

    -- Retrieval counts
    total_candidates INTEGER NOT NULL,
    relevant_count INTEGER NOT NULL,

    -- Core metrics
    recall_at_5 REAL,
    recall_at_10 REAL,
    mrr REAL,
    ndcg_at_5 REAL,
    ndcg_at_10 REAL,

    -- Context
    top_score REAL,
    avg_score REAL,
    confidence_level TEXT,
    used_external BOOLEAN DEFAULT false,
    latency_ms INTEGER,

    -- RAG-030: Latency breakdown per component
    latency_breakdown JSONB,

    created_at TIMESTAMPTZ DEFAULT NOW(),
    tenant_id UUID DEFAULT '00000000-0000-0000-0000-000000000001'::uuid
);

CREATE INDEX IF NOT EXISTS idx_retrieval_metrics_domain ON retrieval_metrics(domain);
CREATE INDEX IF NOT EXISTS idx_retrieval_metrics_created ON retrieval_metrics(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_retrieval_metrics_query_hash ON retrieval_metrics(query_hash);

COMMENT ON TABLE retrieval_metrics IS 'RAG-029/030: Stores retrieval quality metrics and latency breakdown per query';

-- ============================================================================
-- RAG-031: Retrieval Evaluation Runs
-- ============================================================================

CREATE TABLE IF NOT EXISTS evaluation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_case_count INTEGER NOT NULL,
    avg_precision REAL NOT NULL,
    avg_recall REAL NOT NULL,
    avg_f1 REAL NOT NULL,
    avg_mrr REAL NOT NULL,
    domain TEXT,
    top_k INTEGER NOT NULL,
    results JSONB,  -- Per-case results for detailed analysis
    created_at TIMESTAMPTZ DEFAULT NOW(),
    tenant_id UUID DEFAULT '00000000-0000-0000-0000-000000000001'::uuid
);

CREATE INDEX IF NOT EXISTS idx_evaluation_runs_created ON evaluation_runs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_evaluation_runs_domain ON evaluation_runs(domain);

COMMENT ON TABLE evaluation_runs IS 'RAG-031: Stores batch evaluation runs for retrieval quality testing';

-- ============================================================================
-- RAG-033: A/B Testing Framework
-- ============================================================================

CREATE TABLE IF NOT EXISTS ab_experiments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'draft',  -- draft, active, paused, completed
    traffic_percentage INTEGER NOT NULL DEFAULT 100,
    variants JSONB NOT NULL,  -- [{"id": "control", "weight": 50, "config": {...}}]
    domain_filter TEXT[],
    start_time TIMESTAMPTZ,
    end_time TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    tenant_id UUID DEFAULT '00000000-0000-0000-0000-000000000001'::uuid
);

CREATE INDEX IF NOT EXISTS idx_ab_experiments_status ON ab_experiments(status);
CREATE INDEX IF NOT EXISTS idx_ab_experiments_active ON ab_experiments(status, start_time, end_time)
    WHERE status = 'active';

COMMENT ON TABLE ab_experiments IS 'RAG-033: A/B experiment definitions for retrieval pipeline testing';

-- RAG-033: Extend retrieval_metrics with experiment tracking
ALTER TABLE retrieval_metrics
    ADD COLUMN IF NOT EXISTS experiment_id UUID,
    ADD COLUMN IF NOT EXISTS variant_id TEXT;

CREATE INDEX IF NOT EXISTS idx_retrieval_metrics_experiment
    ON retrieval_metrics(experiment_id, variant_id)
    WHERE experiment_id IS NOT NULL;

-- ============================================================================
-- MEM-001: User Memory System
-- Purpose: Fast personal context layer alongside RAG pipeline
-- ============================================================================

-- Core memory storage table
CREATE TABLE IF NOT EXISTS user_memories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid
        REFERENCES tenants(id) ON DELETE CASCADE,
    memory_type TEXT NOT NULL DEFAULT 'fact',  -- fact, preference, context, project, technical
    content TEXT NOT NULL,
    importance REAL NOT NULL DEFAULT 0.5,      -- 0.0-1.0
    content_hash TEXT NOT NULL,                -- SHA-256 for deduplication
    source TEXT NOT NULL DEFAULT 'explicit',   -- explicit, extracted, inferred, compaction
    app_id TEXT,                               -- Which app created this memory
    metadata JSONB NOT NULL DEFAULT '{}',
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_user_memories_user ON user_memories(user_id, tenant_id);
CREATE INDEX IF NOT EXISTS idx_user_memories_type ON user_memories(user_id, memory_type);
CREATE INDEX IF NOT EXISTS idx_user_memories_importance ON user_memories(user_id, importance DESC);
CREATE INDEX IF NOT EXISTS idx_user_memories_hash ON user_memories(content_hash);
CREATE INDEX IF NOT EXISTS idx_user_memories_expires ON user_memories(expires_at)
    WHERE expires_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_user_memories_app ON user_memories(app_id)
    WHERE app_id IS NOT NULL;

DROP TRIGGER IF EXISTS user_memories_touch_updated_at ON user_memories;
CREATE TRIGGER user_memories_touch_updated_at
    BEFORE UPDATE ON user_memories
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

COMMENT ON TABLE user_memories IS 'MEM-001: User preferences, facts, and context for personalized responses';

-- ============================================================================
-- MEM-002: Per-App Memory Configuration
-- ============================================================================

CREATE TABLE IF NOT EXISTS app_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    app_id TEXT NOT NULL UNIQUE,
    app_name TEXT,
    memory_enabled BOOLEAN NOT NULL DEFAULT true,
    memory_priority REAL NOT NULL DEFAULT 0.5,           -- 0.0-1.0, weight for memory vs RAG
    auto_extract_enabled BOOLEAN NOT NULL DEFAULT true,
    confidence_threshold REAL NOT NULL DEFAULT 0.7,      -- Minimum confidence for memory-only response
    max_memories_per_user INTEGER NOT NULL DEFAULT 500,
    settings JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DROP TRIGGER IF EXISTS app_configs_touch_updated_at ON app_configs;
CREATE TRIGGER app_configs_touch_updated_at
    BEFORE UPDATE ON app_configs
    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Seed default app configurations
INSERT INTO app_configs (app_id, app_name, memory_priority, auto_extract_enabled, confidence_threshold)
VALUES
    ('gridlight-chat', 'Gridlight Chat', 0.6, true, 0.7),
    ('film-engine', 'Film Engine', 0.85, true, 0.6),
    ('gridlight-support', 'Gridlight Support', 0.3, false, 0.85),
    ('gridlight-games', 'Gridlight Games', 1.0, true, 0.5)
ON CONFLICT (app_id) DO NOTHING;

COMMENT ON TABLE app_configs IS 'MEM-002: Per-app configuration for memory vs RAG balance';

-- ============================================================================
-- Memory Access Log (Epic 11 LoRA Bridge)
-- Purpose: Track memory access patterns to inform LoRA distillation priority
-- ============================================================================

CREATE TABLE IF NOT EXISTS memory_access_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    memory_id UUID REFERENCES user_memories(id) ON DELETE SET NULL,
    user_id TEXT NOT NULL,
    tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid,
    access_type TEXT NOT NULL DEFAULT 'read',  -- read, write, update, delete
    app_id TEXT,
    query_hash TEXT,      -- Links to retrieval_metrics for LoRA bridge
    latency_ms INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_memory_access_log_memory ON memory_access_log(memory_id)
    WHERE memory_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_memory_access_log_user ON memory_access_log(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memory_access_log_created ON memory_access_log(created_at DESC);

COMMENT ON TABLE memory_access_log IS 'Memory access patterns for Epic 11 LoRA distillation priority';

-- MEM-IMP-011: Conversation events — append-only log for async memory extraction
CREATE TABLE IF NOT EXISTS conversation_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id TEXT NOT NULL,
    tenant_id UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001'::uuid,
    session_id UUID NOT NULL,
    event_type TEXT NOT NULL,   -- user_message, assistant_message, memory_write, memory_read
    content TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conversation_events_user_session
    ON conversation_events(user_id, session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_conversation_events_session
    ON conversation_events(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_conversation_events_type
    ON conversation_events(event_type, created_at DESC);

COMMENT ON TABLE conversation_events IS 'MEM-IMP-011: Append-only event log for async memory extraction pipeline';

-- CHAT-001: Chat session metadata for persistent conversation history
CREATE TABLE IF NOT EXISTS chat_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    app_id TEXT NOT NULL DEFAULT 'gridlight-chat',
    title TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chat_sessions_user
    ON chat_sessions(user_id, app_id, updated_at DESC);

COMMENT ON TABLE chat_sessions IS 'CHAT-001: Chat session metadata; messages stored in conversation_events keyed by session_id';
