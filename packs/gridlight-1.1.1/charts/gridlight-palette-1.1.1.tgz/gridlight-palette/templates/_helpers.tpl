{{/*
Expand the name of the chart.
*/}}
{{- define "gridlight.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "gridlight.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels applied to all resources.
*/}}
{{- define "gridlight.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "gridlight.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/*
Selector labels (stable — used in matchLabels; never add fields that change).
*/}}
{{- define "gridlight.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gridlight.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Resolve image reference: registry/repository:tag.
Handles the case where repository is a template string in values.yaml.
*/}}
{{- define "gridlight.image" -}}
{{- $reg := .Values.global.imageRegistry -}}
{{- $tag := .Values.global.imageTag -}}
{{- printf "%s/%s:%s" $reg .repo $tag -}}
{{- end }}

{{/*
Resolve the effective list of imagePullSecrets.
Uses the chart-managed regcred when registryCredentials is set,
otherwise falls back to global.imagePullSecrets.
*/}}
{{- define "gridlight.imagePullSecrets" -}}
{{- if .Values.auth.registryCredentials }}
- name: {{ include "gridlight.fullname" . }}-regcred
{{- else }}
{{- range .Values.global.imagePullSecrets }}
- name: {{ . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Gateway service DNS name (used by agents to register).
*/}}
{{- define "gridlight.gatewayURL" -}}
{{- printf "http://%s-gateway:%d" (include "gridlight.fullname" .) (.Values.gateway.port | int) -}}
{{- end }}

{{/*
PostgreSQL DSN assembled from in-cluster values.
*/}}
{{- define "gridlight.postgresURL" -}}
{{- printf "postgresql://gridlight:$(POSTGRES_PASSWORD)@%s-postgres:%d/gridlight" (include "gridlight.fullname" .) (.Values.postgres.port | int) -}}
{{- end }}

{{/*
Neo4j Bolt URL.
*/}}
{{- define "gridlight.neo4jURL" -}}
{{- printf "bolt://%s-neo4j:%d" (include "gridlight.fullname" .) (.Values.neo4j.boltPort | int) -}}
{{- end }}

{{/*
Resolved LLM model file path inside the container.
Uses llmAgent.modelPath if set; otherwise derives from models.llm catalog.
*/}}
{{- define "gridlight.llmModelPath" -}}
{{- if .Values.llmAgent.modelPath -}}
{{- .Values.llmAgent.modelPath -}}
{{- else -}}
{{- $cat := index .Values.models.llm.catalog .Values.models.llm.category -}}
{{- $m := index $cat .Values.models.llm.preset -}}
{{- if $m.subdir -}}
{{- printf "%s/models/llm/%s/%s" .Values.dataDir $m.subdir $m.filename -}}
{{- else -}}
{{- printf "%s/models/llm/%s" .Values.dataDir $m.filename -}}
{{- end -}}
{{- end -}}
{{- end }}
