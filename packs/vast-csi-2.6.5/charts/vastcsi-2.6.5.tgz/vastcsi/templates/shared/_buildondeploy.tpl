{{/*
=============================================================================
build-on-deploy: run upstream images on wolfi-base (the ONLY scanned pack image)

Mirrors the NVIDIA VSS 3.x mitigation. Instead of pulling the upstream CSI
sidecar / driver images (which carry the CVE findings), every container runs
.Values.baseImage (cgr.dev/chainguard/wolfi-base, 0 CVEs). A single init
container crane-exports each upstream image's rootfs into /runtime/<key> and
writes a per-image launch.sh that:
  - sets LD_LIBRARY_PATH from the upstream rootfs (matched-ld swap for dynamic
    binaries; static Go sidecars ignore it harmlessly), and
  - execs the upstream image's real Entrypoint+Cmd (read from its OCI config)
    plus the container's args.
pack.content.images therefore lists only wolfi-base -> a 0/0 scan surface, while
the genuine upstream binaries still run.

Usage in a Deployment/DaemonSet pod spec:
  initContainers:
{{ include "vastcsi.bod.initContainer" . | indent 8 }}
  containers:
    - name: csi-provisioner
      image: {{ .Values.baseImage }}
      {{- include "vastcsi.bod.command" (dict "key" "csiProvisioner") | nindent 10 }}
      args: [ ... unchanged ... ]
      volumeMounts:
        - { name: runtime, mountPath: /runtime }   # plus the container's own mounts
  volumes:
    - name: runtime
      emptyDir: {}
=============================================================================
*/}}

{{/* command/launch for one container: runs the crane-extracted binary for <key> */}}
{{- define "vastcsi.bod.command" -}}
command: ["sh", "/runtime/{{ .key }}/launch.sh"]
{{- end -}}

{{/* the shared fetch-runtime init container: cranes every image in .Values.image */}}
{{- define "vastcsi.bod.initContainer" -}}
- name: fetch-runtime
  image: {{ .Values.baseImage }}
  securityContext:
    runAsUser: 0
  command: ["sh", "-c"]
  args:
    - |
      set -e
      apk add --no-cache crane jq >/dev/null 2>&1
      fetch() {
        key="$1"; img="$2"; dir="/runtime/$key"; mkdir -p "$dir"
        for i in 1 2 3 4 5; do
          if crane export "$img" "$dir/rootfs.tar" 2>/dev/null; then
            tar -xf "$dir/rootfs.tar" -C "$dir" && rm -f "$dir/rootfs.tar" && break
          fi
          echo "crane export $key failed (attempt $i) — retrying"; sleep 15
        done
        crane config "$img" > "$dir/image.json" 2>/dev/null || echo '{}' > "$dir/image.json"
        ep="$(jq -r 'try (.config.Entrypoint // []) | join(" ")' "$dir/image.json")"
        cmd="$(jq -r 'try (.config.Cmd // []) | join(" ")' "$dir/image.json")"
        {
          echo '#!/bin/sh'
          echo "RT=\"$dir\""
          echo 'RTLD=$(find "$RT" -name "ld-linux-*.so*" -o -name "ld-musl-*.so*" 2>/dev/null | head -1)'
          echo 'LIBPATH="$(find "$RT" -name "*.so*" -type f | xargs -r -n1 dirname | sort -u | tr "\n" ":")"'
          echo "set -- $ep $cmd \"\$@\""
          echo 'bin="$1"; shift'
          echo 'case "$bin" in /*) [ -x "$RT$bin" ] && bin="$RT$bin";; esac'
          echo '[ -x "$bin" ] || bin=$(find "$RT" -name "$(basename "$bin")" -type f -perm -u+x 2>/dev/null | head -1)'
          echo 'if [ -n "$RTLD" ]; then exec "$RTLD" --library-path "$LIBPATH" "$bin" "$@"; else exec "$bin" "$@"; fi'
        } > "$dir/launch.sh"
        chmod +x "$dir/launch.sh"
        echo "prepared $key -> $(head -c0 /dev/null; cat "$dir/launch.sh" | tail -1)"
      }
{{- range $key, $spec := .Values.image }}
{{- if ne $key "csiVastPlugin" }}
      fetch "{{ $key }}" "{{ printf "%s:%s" $spec.repository (toString $spec.tag) }}"
{{- end }}
{{- end }}
  volumeMounts:
    - name: runtime
      mountPath: /runtime
{{- end -}}
